# Trickster-Win11-Debloat

Полный набор скриптов для зачистки Windows 11 от встроенных компонентов, служб и телеметрии.  
Автор: [trickster-rust](https://github.com/trickster-rust)

## Возможности

- ✔ Отключение и удаление Microsoft Defender (служба, драйвера, политики)
- ✔ Удаление OneDrive, Xbox, Cortana, Feedback, Store, Widgets, GameBar
- ✔ Отключение SmartScreen, Telemetry, CaptureService, Search, SysMain
- ✔ Блокировка обновлений (частично), отключение центра уведомлений
- ✔ ELAM Driver блокировка
- ✔ Удаление драйверов WdBoot.sys и WdFilter.sys в Safe Mode
- ✔ Устранение ошибки `ms-gamingoverlay` при запуске OBS или игр
- ✔ Стабилизация OBS сцены (по результату пользователя)

## Структура

| Файл                          | Назначение                                             |
|------------------------------|--------------------------------------------------------|
| `disable_defender_lite_final.ps1`      | Базовая зачистка Defender, SmartScreen, задач         |
| `disable_defender_deep_ELAM.ps1`      | Глубокое отключение Defender, ELAM, права, Safe Mode  |
| `nuke_defender_fixed.ps1`            | Удаление драйверов Defender из System32 в Safe Mode   |
| `disable_firewall.ps1`               | (опционально) отключение всех профилей брандмауэра    |
| `remove_gamingoverlay_fix.reg`       | Устранение ошибки "ms-gamingoverlay"                  |
| `run_*.bat`                           | Удобный запуск каждого сценария                       |

## Установка

1. Помести все файлы в `C:\debloat`
2. Запускай `.bat` от имени администратора
3. Для `nuke_defender` и `deep_ELAM` — переходи в Safe Mode (boot options)

## Важно

- Используется `SetACL.exe` (скачать: https://helgeklein.com/setacl/downloads/)
- Работает в Windows 11 (включая 23H2+)
- Работоспособность подтверждена вручную

## Автор

**[Trickster](https://github.com/trickster-rust)** — кастомный debloat-подход, OBS-настройки, удаление системных конфликтов.